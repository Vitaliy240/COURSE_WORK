﻿namespace Курсовая_работа
{
    partial class FAQ_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FAQ_Form));
            this.faqBox = new System.Windows.Forms.RichTextBox();
            this.faqTitleLabel = new System.Windows.Forms.Label();
            this.faqAboutBtn = new System.Windows.Forms.Button();
            this.faqLoadBtn = new System.Windows.Forms.Button();
            this.faqSaveBtn = new System.Windows.Forms.Button();
            this.faqDispBtn = new System.Windows.Forms.Button();
            this.faqDelBtn = new System.Windows.Forms.Button();
            this.faqEditBtn = new System.Windows.Forms.Button();
            this.faqAddBtn = new System.Windows.Forms.Button();
            this.faqGeneralBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // faqBox
            // 
            this.faqBox.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqBox, "faqBox");
            this.faqBox.Name = "faqBox";
            this.faqBox.ReadOnly = true;
            // 
            // faqTitleLabel
            // 
            resources.ApplyResources(this.faqTitleLabel, "faqTitleLabel");
            this.faqTitleLabel.Name = "faqTitleLabel";
            // 
            // faqAboutBtn
            // 
            this.faqAboutBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqAboutBtn, "faqAboutBtn");
            this.faqAboutBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqAboutBtn.FlatAppearance.BorderSize = 0;
            this.faqAboutBtn.Name = "faqAboutBtn";
            this.faqAboutBtn.UseVisualStyleBackColor = false;
            this.faqAboutBtn.Click += new System.EventHandler(this.faqAboutBtn_Click);
            // 
            // faqLoadBtn
            // 
            this.faqLoadBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqLoadBtn, "faqLoadBtn");
            this.faqLoadBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqLoadBtn.FlatAppearance.BorderSize = 0;
            this.faqLoadBtn.Name = "faqLoadBtn";
            this.faqLoadBtn.UseVisualStyleBackColor = false;
            this.faqLoadBtn.Click += new System.EventHandler(this.faqLoadBtn_Click);
            // 
            // faqSaveBtn
            // 
            this.faqSaveBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqSaveBtn, "faqSaveBtn");
            this.faqSaveBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqSaveBtn.FlatAppearance.BorderSize = 0;
            this.faqSaveBtn.Name = "faqSaveBtn";
            this.faqSaveBtn.UseVisualStyleBackColor = false;
            this.faqSaveBtn.Click += new System.EventHandler(this.faqSaveBtn_Click);
            // 
            // faqDispBtn
            // 
            this.faqDispBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqDispBtn, "faqDispBtn");
            this.faqDispBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqDispBtn.FlatAppearance.BorderSize = 0;
            this.faqDispBtn.Name = "faqDispBtn";
            this.faqDispBtn.UseVisualStyleBackColor = false;
            this.faqDispBtn.Click += new System.EventHandler(this.faqDispBtn_Click);
            // 
            // faqDelBtn
            // 
            this.faqDelBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqDelBtn, "faqDelBtn");
            this.faqDelBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqDelBtn.FlatAppearance.BorderSize = 0;
            this.faqDelBtn.Name = "faqDelBtn";
            this.faqDelBtn.UseVisualStyleBackColor = false;
            this.faqDelBtn.Click += new System.EventHandler(this.faqDelBtn_Click);
            // 
            // faqEditBtn
            // 
            this.faqEditBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqEditBtn, "faqEditBtn");
            this.faqEditBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqEditBtn.FlatAppearance.BorderSize = 0;
            this.faqEditBtn.Name = "faqEditBtn";
            this.faqEditBtn.UseVisualStyleBackColor = false;
            this.faqEditBtn.Click += new System.EventHandler(this.faqEditBtn_Click);
            // 
            // faqAddBtn
            // 
            this.faqAddBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqAddBtn, "faqAddBtn");
            this.faqAddBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqAddBtn.FlatAppearance.BorderSize = 0;
            this.faqAddBtn.Name = "faqAddBtn";
            this.faqAddBtn.UseVisualStyleBackColor = false;
            this.faqAddBtn.Click += new System.EventHandler(this.faqAddBtn_Click);
            // 
            // faqGeneralBtn
            // 
            this.faqGeneralBtn.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.faqGeneralBtn, "faqGeneralBtn");
            this.faqGeneralBtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.faqGeneralBtn.FlatAppearance.BorderSize = 0;
            this.faqGeneralBtn.Name = "faqGeneralBtn";
            this.faqGeneralBtn.UseVisualStyleBackColor = false;
            this.faqGeneralBtn.Click += new System.EventHandler(this.faqGeneralBtn_Click);
            // 
            // FAQ_Form
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.faqAboutBtn);
            this.Controls.Add(this.faqLoadBtn);
            this.Controls.Add(this.faqSaveBtn);
            this.Controls.Add(this.faqDispBtn);
            this.Controls.Add(this.faqDelBtn);
            this.Controls.Add(this.faqEditBtn);
            this.Controls.Add(this.faqAddBtn);
            this.Controls.Add(this.faqTitleLabel);
            this.Controls.Add(this.faqGeneralBtn);
            this.Controls.Add(this.faqBox);
            this.MaximizeBox = false;
            this.Name = "FAQ_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox faqBox;
        private System.Windows.Forms.Button faqGeneralBtn;
        private System.Windows.Forms.Label faqTitleLabel;
        private System.Windows.Forms.Button faqAddBtn;
        private System.Windows.Forms.Button faqEditBtn;
        private System.Windows.Forms.Button faqDelBtn;
        private System.Windows.Forms.Button faqDispBtn;
        private System.Windows.Forms.Button faqSaveBtn;
        private System.Windows.Forms.Button faqLoadBtn;
        private System.Windows.Forms.Button faqAboutBtn;
    }
}