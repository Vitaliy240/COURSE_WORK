﻿namespace Курсовая_работа
{
    partial class Add_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Form));
            this.addConsignmentLabel = new System.Windows.Forms.Label();
            this.addStoreNumberLabel = new System.Windows.Forms.Label();
            this.addQuantityLabel = new System.Windows.Forms.Label();
            this.addPriceLabel = new System.Windows.Forms.Label();
            this.addFirmLabel = new System.Windows.Forms.Label();
            this.addNameLabel = new System.Windows.Forms.Label();
            this.consignmentBox = new System.Windows.Forms.TextBox();
            this.storeNumberBox = new System.Windows.Forms.TextBox();
            this.quantityBox = new System.Windows.Forms.TextBox();
            this.priceBox = new System.Windows.Forms.TextBox();
            this.manufactureBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.carShopLabel = new System.Windows.Forms.Label();
            this.addDBBtn = new System.Windows.Forms.Button();
            this.backBtn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addConsignmentLabel
            // 
            this.addConsignmentLabel.AutoSize = true;
            this.addConsignmentLabel.BackColor = System.Drawing.Color.Transparent;
            this.addConsignmentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addConsignmentLabel.Location = new System.Drawing.Point(197, 321);
            this.addConsignmentLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addConsignmentLabel.Name = "addConsignmentLabel";
            this.addConsignmentLabel.Size = new System.Drawing.Size(174, 20);
            this.addConsignmentLabel.TabIndex = 25;
            this.addConsignmentLabel.Text = "Minimum Consignment:";
            // 
            // addStoreNumberLabel
            // 
            this.addStoreNumberLabel.AutoSize = true;
            this.addStoreNumberLabel.BackColor = System.Drawing.Color.Transparent;
            this.addStoreNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addStoreNumberLabel.Location = new System.Drawing.Point(253, 278);
            this.addStoreNumberLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addStoreNumberLabel.Name = "addStoreNumberLabel";
            this.addStoreNumberLabel.Size = new System.Drawing.Size(112, 20);
            this.addStoreNumberLabel.TabIndex = 24;
            this.addStoreNumberLabel.Text = "Store Number:";
            // 
            // addQuantityLabel
            // 
            this.addQuantityLabel.AutoSize = true;
            this.addQuantityLabel.BackColor = System.Drawing.Color.Transparent;
            this.addQuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addQuantityLabel.Location = new System.Drawing.Point(293, 236);
            this.addQuantityLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addQuantityLabel.Name = "addQuantityLabel";
            this.addQuantityLabel.Size = new System.Drawing.Size(72, 20);
            this.addQuantityLabel.TabIndex = 23;
            this.addQuantityLabel.Text = "Quantity:";
            // 
            // addPriceLabel
            // 
            this.addPriceLabel.AutoSize = true;
            this.addPriceLabel.BackColor = System.Drawing.Color.Transparent;
            this.addPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addPriceLabel.Location = new System.Drawing.Point(284, 193);
            this.addPriceLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addPriceLabel.Name = "addPriceLabel";
            this.addPriceLabel.Size = new System.Drawing.Size(81, 20);
            this.addPriceLabel.TabIndex = 22;
            this.addPriceLabel.Text = "Unit Price:";
            // 
            // addFirmLabel
            // 
            this.addFirmLabel.AutoSize = true;
            this.addFirmLabel.BackColor = System.Drawing.Color.Transparent;
            this.addFirmLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addFirmLabel.Location = new System.Drawing.Point(257, 149);
            this.addFirmLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addFirmLabel.Name = "addFirmLabel";
            this.addFirmLabel.Size = new System.Drawing.Size(108, 20);
            this.addFirmLabel.TabIndex = 21;
            this.addFirmLabel.Text = "Manufacturer:";
            // 
            // addNameLabel
            // 
            this.addNameLabel.AutoSize = true;
            this.addNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.addNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addNameLabel.Location = new System.Drawing.Point(251, 106);
            this.addNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addNameLabel.Name = "addNameLabel";
            this.addNameLabel.Size = new System.Drawing.Size(114, 20);
            this.addNameLabel.TabIndex = 20;
            this.addNameLabel.Text = "Product Name:";
            // 
            // consignmentBox
            // 
            this.consignmentBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.consignmentBox.Location = new System.Drawing.Point(375, 318);
            this.consignmentBox.Margin = new System.Windows.Forms.Padding(2);
            this.consignmentBox.Name = "consignmentBox";
            this.consignmentBox.Size = new System.Drawing.Size(181, 26);
            this.consignmentBox.TabIndex = 19;
            // 
            // storeNumberBox
            // 
            this.storeNumberBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.storeNumberBox.Location = new System.Drawing.Point(375, 275);
            this.storeNumberBox.Margin = new System.Windows.Forms.Padding(2);
            this.storeNumberBox.Name = "storeNumberBox";
            this.storeNumberBox.Size = new System.Drawing.Size(181, 26);
            this.storeNumberBox.TabIndex = 18;
            // 
            // quantityBox
            // 
            this.quantityBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.quantityBox.Location = new System.Drawing.Point(375, 233);
            this.quantityBox.Margin = new System.Windows.Forms.Padding(2);
            this.quantityBox.Name = "quantityBox";
            this.quantityBox.Size = new System.Drawing.Size(181, 26);
            this.quantityBox.TabIndex = 17;
            // 
            // priceBox
            // 
            this.priceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.priceBox.Location = new System.Drawing.Point(375, 190);
            this.priceBox.Margin = new System.Windows.Forms.Padding(2);
            this.priceBox.Name = "priceBox";
            this.priceBox.Size = new System.Drawing.Size(181, 26);
            this.priceBox.TabIndex = 16;
            // 
            // manufactureBox
            // 
            this.manufactureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.manufactureBox.Location = new System.Drawing.Point(375, 146);
            this.manufactureBox.Margin = new System.Windows.Forms.Padding(2);
            this.manufactureBox.Name = "manufactureBox";
            this.manufactureBox.Size = new System.Drawing.Size(181, 26);
            this.manufactureBox.TabIndex = 15;
            // 
            // nameBox
            // 
            this.nameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameBox.Location = new System.Drawing.Point(375, 103);
            this.nameBox.Margin = new System.Windows.Forms.Padding(2);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(181, 26);
            this.nameBox.TabIndex = 14;
            // 
            // carShopLabel
            // 
            this.carShopLabel.AutoSize = true;
            this.carShopLabel.BackColor = System.Drawing.Color.Transparent;
            this.carShopLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.carShopLabel.Location = new System.Drawing.Point(329, 41);
            this.carShopLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.carShopLabel.Name = "carShopLabel";
            this.carShopLabel.Size = new System.Drawing.Size(158, 31);
            this.carShopLabel.TabIndex = 13;
            this.carShopLabel.Text = "Adding data";
            // 
            // addDBBtn
            // 
            this.addDBBtn.BackColor = System.Drawing.SystemColors.Control;
            this.addDBBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.addDBBtn.Location = new System.Drawing.Point(349, 376);
            this.addDBBtn.Name = "addDBBtn";
            this.addDBBtn.Size = new System.Drawing.Size(99, 37);
            this.addDBBtn.TabIndex = 26;
            this.addDBBtn.Text = "Add";
            this.addDBBtn.UseVisualStyleBackColor = false;
            this.addDBBtn.Click += new System.EventHandler(this.addDBBtn_Click);
            // 
            // backBtn1
            // 
            this.backBtn1.BackColor = System.Drawing.SystemColors.Control;
            this.backBtn1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("backBtn1.BackgroundImage")));
            this.backBtn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.backBtn1.FlatAppearance.BorderSize = 0;
            this.backBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.backBtn1.Location = new System.Drawing.Point(8, 12);
            this.backBtn1.Name = "backBtn1";
            this.backBtn1.Size = new System.Drawing.Size(99, 41);
            this.backBtn1.TabIndex = 27;
            this.backBtn1.UseVisualStyleBackColor = false;
            this.backBtn1.Click += new System.EventHandler(this.backBtn1_Click);
            // 
            // Add_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.backBtn1);
            this.Controls.Add(this.addDBBtn);
            this.Controls.Add(this.addConsignmentLabel);
            this.Controls.Add(this.addStoreNumberLabel);
            this.Controls.Add(this.addQuantityLabel);
            this.Controls.Add(this.addPriceLabel);
            this.Controls.Add(this.addFirmLabel);
            this.Controls.Add(this.addNameLabel);
            this.Controls.Add(this.consignmentBox);
            this.Controls.Add(this.storeNumberBox);
            this.Controls.Add(this.quantityBox);
            this.Controls.Add(this.priceBox);
            this.Controls.Add(this.manufactureBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.carShopLabel);
            this.MaximizeBox = false;
            this.Name = "Add_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Form";
            this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.Add_Form_HelpRequested);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addConsignmentLabel;
        private System.Windows.Forms.Label addStoreNumberLabel;
        private System.Windows.Forms.Label addQuantityLabel;
        private System.Windows.Forms.Label addPriceLabel;
        private System.Windows.Forms.Label addFirmLabel;
        private System.Windows.Forms.Label addNameLabel;
        private System.Windows.Forms.TextBox consignmentBox;
        private System.Windows.Forms.TextBox storeNumberBox;
        private System.Windows.Forms.TextBox quantityBox;
        private System.Windows.Forms.TextBox priceBox;
        private System.Windows.Forms.TextBox manufactureBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label carShopLabel;
        private System.Windows.Forms.Button addDBBtn;
        private System.Windows.Forms.Button backBtn1;
    }
}